
import React from "react";
import "./App.css";

export default function SoberInPublicSite() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans">
      {/* Hero Section */}
      <section className="h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: 'url(/label-hero.jpg)' }}>
        <div className="text-center bg-black bg-opacity-60 p-8 rounded-2xl shadow-xl">
          <h1 className="text-5xl font-bold mb-4">Sober in Public Records</h1>
          <p className="text-xl italic">Born in Botswana. Built for the underground.</p>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-8 bg-zinc-900">
        <h2 className="text-3xl font-bold mb-4">About the Label</h2>
        <p className="max-w-3xl text-lg">
          Sober in Public Records was founded in Botswana as a response to the lack of authentic representation in the music scene. Born out of the underground, the label champions raw talent and unapologetic expression. What began as a collective of rebellious creatives quickly grew into a full-fledged home for outliers, dreamers, and rule-breakers. With Bloody as its flagship artist, the label is building a new narrative—real, raw, and rooted in truth.
        </p>
      </section>

      {/* Promo Video Section */}
      <section className="py-16 px-8 bg-black">
        <h2 className="text-3xl font-bold mb-4">Watch Our Story</h2>
        <div className="aspect-video max-w-4xl mx-auto">
          <iframe className="w-full h-full rounded-xl" src="https://www.youtube.com/embed/vD0CdJtsYKM" title="Sober in Public Promo Video" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
        </div>
      </section>

      {/* Artist Card */}
      <section className="py-16 px-8 bg-zinc-900">
        <h2 className="text-3xl font-bold mb-4">Featured Artist</h2>
        <div className="max-w-md mx-auto bg-zinc-800 p-6 rounded-2xl shadow-xl">
          <img src="/bloody.jpg" alt="Bloody" className="rounded-xl mb-4" />
          <h3 className="text-2xl font-semibold mb-2">Bloody</h3>
          <p>
            Botswana-born artist blending raw emotion, sharp lyricism, and experimental sounds. Bloody leads the charge for a new wave of fearless creatives under Sober in Public.
          </p>
        </div>
      </section>

      {/* Roster Section */}
      <section className="py-16 px-8 bg-black">
        <h2 className="text-3xl font-bold mb-4">Artist Roster</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-zinc-800 p-4 rounded-xl text-center">
            <img src="/bloody.jpg" alt="Bloody" className="rounded-xl mb-2" />
            <h3 className="text-xl font-semibold">Bloody</h3>
            <p className="text-sm">Experimental, raw, and fearless—Bloody defines the label’s edge.</p>
            <a href="#" className="text-red-500 hover:underline text-sm">Listen</a>
          </div>
        </div>
      </section>

      {/* Submission Form */}
      <section className="py-16 px-8 bg-zinc-900">
        <h2 className="text-3xl font-bold mb-4">Join the Label</h2>
        <form className="grid gap-4 max-w-xl mx-auto">
          <input type="text" placeholder="Artist Name" className="p-3 rounded-xl bg-zinc-800 text-white" />
          <input type="email" placeholder="Email" className="p-3 rounded-xl bg-zinc-800 text-white" />
          <textarea placeholder="Tell us about your music" rows="4" className="p-3 rounded-xl bg-zinc-800 text-white" />
          <button type="submit" className="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-xl text-white font-semibold">Submit</button>
        </form>
      </section>
    </div>
  );
}
